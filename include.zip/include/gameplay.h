// gameplay.h
#ifndef GAMEPLAY_H
#define GAMEPLAY_H

void playTwoPlayerGame();
void playWithBotGame();

#endif
